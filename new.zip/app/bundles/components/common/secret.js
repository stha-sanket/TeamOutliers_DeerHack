export const CLIENT_ID = "78658292174-9sq2qq083cg83i70dpfvo7piid5aboob.apps.googleusercontent.com"
export const CLIENT_SECRET = "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"

export const NEXTAUTH_SECRET = "strong-password"
export const JWT_SECRET = "asjdbfasjbflaskdjf"
export const NEXTAUTH_URL = "https://theworldofwagers.com"

export const TSECRET = "lakmflkamtalkam"
export const PRODUCT_CODE = "EPAYTEST"
export const Admins = ["fwr8vuzt7trlis"]