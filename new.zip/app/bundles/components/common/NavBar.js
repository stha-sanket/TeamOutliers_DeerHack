"use client";

export default function NavBar({ }) {
    return <>
        <nav class="bg-[var(--background-sec)] shadow border-b border-b-[#8686864d]" data-type="nav-section">
            <div class="w-[90%] max-w-[1500px] mx-auto px-4">
                <div class="fc justify-between h-16 md:h-20 xl:h-24">
                    <div class="fc gap-3 overflow-hidden">
                        <div class="relative fc h-[50px] min-w-[40px]">
                            <a href="/">
                                <img loading="lazy" src="/icon.ico" class="w-[40px] md:w-[50px]" />
                            </a>
                        </div>
                        <a class="hidden md:block overflow-hidden mr-2" href="/">
                            <h4 class="text-lg md:text-xl text-nowrap overflow-hidden text-ellipsis font-semibold">ConceptC</h4>
                        </a>
                    </div>
                    <div class="hidden flex-grow h-full md:flex justify-end items-center space-x-6">
                        <div class="group relative h-full flex">
                            <h3 class="capitalize select-none cursor-pointer flex gap-1 items-center transition-all duration-300">
                                <span class="capitalize para">Simulation</span>
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="group-hover:rotate-180 transition-transform" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z">
                                    </path>
                                </svg>
                            </h3>
                            <div class="l">
                                <div class="hidden group-hover:flex flex-col absolute top-3/4 -left-4 bg-[var(--background-sec)] shadow-lg rounded-md w-[250px] border border-[#8686864d] z-10">
                                    <a class="flex p-2 border-b items-center justify-between">
                                        <h3 class="para col-pri capitalize ml-1">
                                            <span class="col-sec font-semibold">Simulation</span>
                                        </h3>
                                    </a>
                                    <div class="flex flex-col">
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/lens">
                                            Lens
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/projectile">
                                            Projectile
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/swimming">
                                            Swimming
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/vector">
                                            Vector
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="group relative h-full flex">
                            <h3 class="capitalize select-none cursor-pointer flex gap-1 items-center transition-all duration-300">
                                <span class="capitalize para">3D Models</span>
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="group-hover:rotate-180 transition-transform" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z">
                                    </path>
                                </svg>
                            </h3>
                            <div class="l">
                                <div class="hidden group-hover:flex flex-col absolute top-3/4 -left-4 bg-[var(--background-sec)] shadow-lg rounded-md w-[250px] border border-[#8686864d] z-10">
                                    <a class="flex p-2 border-b items-center justify-between">
                                        <h3 class="para col-pri capitalize ml-1">
                                            <span class="col-sec font-semibold">3D Models</span>
                                        </h3>
                                    </a>
                                    <div class="flex flex-col">
                                            <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/biology/view-3D/heart.glb">
                                                Heart
                                            </a>
                                            <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/biology/view-3D/digestive.glb">
                                                Digestive System
                                            </a>
                                            <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/biology/view-3D/dharara.glb">
                                                Dharara
                                            </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="group relative h-full flex">
                            <h3 class="capitalize select-none cursor-pointer flex gap-1 items-center transition-all duration-300">
                                <span class="capitalize para">Biology</span>
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="group-hover:rotate-180 transition-transform" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z">
                                    </path>
                                </svg>
                            </h3>
                            <div class="l">
                                <div class="hidden group-hover:flex flex-col absolute top-3/4 -left-4 bg-[var(--background-sec)] shadow-lg rounded-md w-[250px] border border-[#8686864d] z-10">
                                    <a class="flex p-2 border-b items-center justify-between">
                                        <h3 class="para col-pri capitalize ml-1">
                                            <span class="col-sec font-semibold">Biology</span>
                                        </h3>
                                    </a>
                                    <div class="flex flex-col">
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/biology/view-3D/heart.glb">
                                            Heart
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/biology/view-3D/digestive-system.glb">
                                            Digestive System
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="group relative h-full flex">
                            <h3 class="capitalize select-none cursor-pointer flex gap-1 items-center transition-all duration-300">
                                <span class="capitalize para">Physics</span>
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="group-hover:rotate-180 transition-transform" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z">
                                    </path>
                                </svg>
                            </h3>
                            <div class="l">
                                <div class="hidden group-hover:flex flex-col absolute top-3/4 -left-4 bg-[var(--background-sec)] shadow-lg rounded-md w-[250px] border border-[#8686864d] z-10">
                                    <a class="flex p-2 border-b items-center justify-between">
                                        <h3 class="para col-pri capitalize ml-1">
                                            <span class="col-sec font-semibold">Physics</span>
                                        </h3>
                                    </a>
                                    <div class="flex flex-col">
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/lens">
                                            Lens
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/projectile">
                                            Projectile
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/swimming">
                                            Swimming
                                        </a>
                                        <a class="fc gap-2 p-2 border-b border-b-[#8686864d] hover:bg-[var(--hover-pri)] para" href="/board/physic/simulation/vector">
                                            Vector
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative group">
                            <div class="rounded-full cursor-pointer">
                                <img loading="lazy" src="/icon.ico" class="min-w-[32px] min-h-[32px] w-[32px] h-[32px]" />
                            </div>
                        </div>
                    </div>
                    <button class="md:hidden fc justify-center rounded">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 20 20" aria-hidden="true" class="transition-all duration-300 rotate-180" height="30" width="30" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd">
                            </path>
                        </svg>
                    </button>
                </div>
            </div>
        </nav>
    </>
};