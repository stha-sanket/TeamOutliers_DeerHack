class GOOGLE_API:
    G1 = "AIzaSyC5vV39ZKWoHz16J7FHYlJ-oeZebT6Dk6g"


class ALL_CREDS(GOOGLE_API):
    pass
