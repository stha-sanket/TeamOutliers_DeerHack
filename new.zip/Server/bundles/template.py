from langchain_core.messages import SystemMessage

CHATBOT_INITIALIZER_SYSTEM_PROMPT = SystemMessage(content="""Answer my questions.""")
